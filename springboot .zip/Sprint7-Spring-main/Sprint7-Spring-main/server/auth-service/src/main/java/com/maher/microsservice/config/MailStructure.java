package com.maher.microsservice.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MailStructure {
    public String subject;
    public String body;
}
