package com.ahmed.singers.repos;

import com.ahmed.singers.entities.Label;
import org.springframework.data.jpa.repository.JpaRepository;
public interface LabelRepository extends JpaRepository<Label, Long> {

}
