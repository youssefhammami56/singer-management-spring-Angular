package com.ahmed.singers.entities;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Singer {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long idSinger;
    private String name;
    private String country;
    private String genre;
    private Date birthDate;
    @ManyToOne
    private Label label;
    @OneToOne
    private Image image;

    public Singer() {
        super();
    }

    public Singer(String name, String country, String genre, Date birthDate) {
        super();
        this.name = name;
        this.country = country;
        this.genre = genre;
        this.birthDate = birthDate;
    }

    public Long getIdSinger() {
        return idSinger;
    }

    public void setIdSinger(Long idSinger) {
        this.idSinger = idSinger;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Singers{" +
                "idSinger=" + idSinger +
                ", name='" + name + '\'' +
                ", country='" + country + '\'' +
                ", genre='" + genre + '\'' +
                ", birthDate=" + birthDate +
                '}';
    }
}
