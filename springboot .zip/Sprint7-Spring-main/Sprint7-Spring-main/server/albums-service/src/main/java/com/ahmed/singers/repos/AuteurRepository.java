package com.ahmed.singers.repos;

import com.ahmed.singers.entities.Auteur;
import com.ahmed.singers.entities.Singer;
import com.ahmed.singers.entities.Label;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource (path = "rest")
public interface AuteurRepository extends JpaRepository<Auteur, Long> {
    List<Auteur> findByName(String name);
    List<Auteur> findByNameContains(String name);



}
