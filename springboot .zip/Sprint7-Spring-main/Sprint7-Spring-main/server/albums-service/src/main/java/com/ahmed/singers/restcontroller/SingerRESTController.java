package com.ahmed.singers.restcontroller;

import com.ahmed.singers.dto.SingerDTO;
import com.ahmed.singers.entities.Singer;
import com.ahmed.singers.service.SingerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class SingerRESTController {
    @Autowired
    SingerService singerService;

    @RequestMapping(value = "/allSingers", method = RequestMethod.GET)
    public List<SingerDTO> getAllSingers() {
        return singerService.getAllSingers();
    }

    @RequestMapping(value = "/singer/{id}", method = RequestMethod.GET)
    public SingerDTO getSingerById(@PathVariable("id") Long id) {
        return singerService.getSinger(id);
    }

    @RequestMapping(path = "addSinger", method = RequestMethod.POST)
    public SingerDTO createSinger(@RequestBody SingerDTO a) {
        return singerService.saveSinger(a);
    }

    @RequestMapping(path = "/updateSinger", method = RequestMethod.PUT)
    public SingerDTO updateSinger(@RequestBody SingerDTO a) {
        return singerService.updateSinger(a);
    }

    @RequestMapping(value = "/deleteSinger/{id}", method = RequestMethod.DELETE)
    public void deleteSinger(@PathVariable("id") Long id) {
        singerService.deleteSingerById(id);
    }

    @RequestMapping(value = "/label/{idLabel}", method = RequestMethod.GET)
    public List<Singer> getSingersByLabel(@PathVariable("idLabel") Long idLabel) {
        return singerService.findByLabelIdLabel(idLabel);
    }
}
