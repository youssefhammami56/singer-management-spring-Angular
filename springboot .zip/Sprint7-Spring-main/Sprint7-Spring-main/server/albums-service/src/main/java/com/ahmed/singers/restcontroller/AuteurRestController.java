package com.ahmed.singers.restcontroller;

import com.ahmed.singers.entities.Auteur;
import com.ahmed.singers.repos.AuteurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AuteurRestController {
    @Autowired
    private final AuteurRepository auteurRepository;

    public AuteurRestController(AuteurRepository auteurRepository) {
        this.auteurRepository = auteurRepository;
    }

    @GetMapping("/listAll")
    public List<Auteur> listAll() {
        return auteurRepository.findAll();
    }
}

