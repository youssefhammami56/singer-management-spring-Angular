package com.ahmed.singers.service;

import com.ahmed.singers.dto.SingerDTO;
import com.ahmed.singers.entities.Singer;
import com.ahmed.singers.entities.Label;
import com.ahmed.singers.repos.SingerRepository;
import com.ahmed.singers.repos.ImageRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SingerServiceImpl implements SingerService {
    @Autowired
    SingerRepository singerRepository;
    @Autowired
    ImageRepository imageRepository;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public SingerDTO saveSinger(SingerDTO a) {
        return convertEntityToDTO(singerRepository.save(convertDTOToEntity(a)));
    }

    @Override
    public SingerDTO updateSinger(SingerDTO a) {
        Long oldImageId = this.getSinger(a.getIdSinger()).getImage().getIdImage();
        Long newImageId = a.getImage().getIdImage();
        Singer singerUpdated = singerRepository.save(convertDTOToEntity(a));
        if (oldImageId != newImageId) {
            imageRepository.deleteById(oldImageId);
        }
        return convertEntityToDTO(singerUpdated);
    }

    @Override
    public void deleteSinger(Singer a) {
        singerRepository.delete(a);
    }

    @Override
    public void deleteSingerById(Long id) {
        singerRepository.deleteById(id);
    }

    @Override
    public SingerDTO getSinger(Long id) {
        return convertEntityToDTO(singerRepository.findById(id).get());
    }

    @Override
    public List<SingerDTO> getAllSingers() {
        return singerRepository.findAll().stream().map(this::convertEntityToDTO).collect(Collectors.toList());
    }

    // Methods From SingerRepository

    @Override
    public List<Singer> findByName(String name) {
        return singerRepository.findByName(name);
    }

    @Override
    public List<Singer> findByNameContains(String name) {
        return singerRepository.findByNameContains(name);
    }

    @Override
    public List<Singer> findByGenre(String genre) {
        return singerRepository.findByGenre(genre);
    }

    @Override
    public List<Singer> findByLabel(Label label) {
        return singerRepository.findByLabel(label);
    }

    @Override
    public List<Singer> findByLabelIdLabel(Long id) {
        return singerRepository.findByLabelIdLabel(id);
    }

    @Override
    public List<Singer> findByOrderByNameAsc() {
        return singerRepository.findByOrderByNameAsc();
    }

    @Override
    public List<Singer> sortByNameAndGenre() {
        return singerRepository.sortByNameAndGenre();
    }

    @Override
    public SingerDTO convertEntityToDTO(Singer a) {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
        SingerDTO singerDTO = modelMapper.map(a, SingerDTO.class);
        return singerDTO;
    }

    @Override
    public Singer convertDTOToEntity(SingerDTO a) {
        Singer singer = new Singer();
        singer = modelMapper.map(a, Singer.class);
        return singer;
    }
}

