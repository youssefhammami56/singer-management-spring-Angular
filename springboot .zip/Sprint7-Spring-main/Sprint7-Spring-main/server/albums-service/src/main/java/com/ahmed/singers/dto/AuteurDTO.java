package com.ahmed.singers.dto;

import com.ahmed.singers.entities.Image;
import com.ahmed.singers.entities.Label;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuteurDTO {

    private long Id;
    private String nomAuteur;

    private long ageAuteur;
}
