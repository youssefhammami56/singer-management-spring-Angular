package com.ahmed.singers.entities;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Auteur {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long Id;
    private String nomAuteur;

    private long ageAuteur;

    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getNomAuteur() {
        return nomAuteur;
    }

    public void setNomAuteur(String nomAuteur) {
        this.nomAuteur = nomAuteur;
    }

    public long getAgeAuteur() {
        return ageAuteur;
    }

    public void setAgeAuteur(long ageAuteur) {
        this.ageAuteur = ageAuteur;
    }
    @Override
    public String toString() {
        return "Auteurs{" +
                "Id=" + Id +
                ", nomAuteur='" + nomAuteur + '\'' +
                ", ageAuteur='" + ageAuteur + '\'' +

                '}';
    }
}
