package com.ahmed.singers.dto;

import com.ahmed.singers.entities.Image;
import com.ahmed.singers.entities.Label;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SingerDTO {
    private Long idSinger;
    private String name;
    private String country;
    private String genre;
    private Date birthDate;
    private Label label;
    private Image image;
}
