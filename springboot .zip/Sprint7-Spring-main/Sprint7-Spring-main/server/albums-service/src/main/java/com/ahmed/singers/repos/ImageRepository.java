package com.ahmed.singers.repos;

import com.ahmed.singers.entities.Image;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImageRepository extends JpaRepository<Image, Long> {
}
