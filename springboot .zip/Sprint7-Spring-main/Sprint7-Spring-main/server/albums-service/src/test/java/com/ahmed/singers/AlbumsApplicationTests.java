package com.ahmed.singers;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SingersApplicationTests {
}
