package com.ahmed.singers.service;

import com.ahmed.singers.dto.SingerDTO;
import com.ahmed.singers.entities.Singer;
import com.ahmed.singers.entities.Label;

import java.util.List;

public interface SingerService {
    SingerDTO saveSinger(SingerDTO a);
    SingerDTO updateSinger(SingerDTO a);
    void deleteSinger(Singer a);
    void deleteSingerById(Long id);
    SingerDTO getSinger(Long id);
    List<SingerDTO> getAllSingers();
    List<Singer> findByName(String name);
    List<Singer> findByNameContains(String name);
    List<Singer> findByGenre(String genre);
    List<Singer> findByLabel(Label label);
    List<Singer> findByLabelIdLabel(Long id);
    List<Singer> findByOrderByNameAsc();
    List<Singer> sortByNameAndGenre();
    SingerDTO convertEntityToDTO(Singer a);
    Singer convertDTOToEntity(SingerDTO a);
}
