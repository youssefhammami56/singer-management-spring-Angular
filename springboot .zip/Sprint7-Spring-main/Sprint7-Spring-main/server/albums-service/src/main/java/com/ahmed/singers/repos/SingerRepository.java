package com.ahmed.singers.repos;

import com.ahmed.singers.entities.Singer;
import com.ahmed.singers.entities.Label;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource (path = "rest")
public interface SingerRepository extends JpaRepository<Singer, Long> {
    List<Singer> findByName(String name);
    List<Singer> findByNameContains(String name);

    @Query("select a from Singer a where a.genre like %?1")
    List<Singer> findByGenre(String genre);

    @Query("select a from Singer a where a.label = ?1")
    List<Singer> findByLabel(Label label);

    List<Singer> findByLabelIdLabel(Long id);

    List<Singer> findByOrderByNameAsc();

    @Query ("select a from Singer a order by a.name asc, a.genre desc")
    List<Singer> sortByNameAndGenre();

}
